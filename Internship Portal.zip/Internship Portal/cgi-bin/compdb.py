#!usr/bin/python
import sqlite3

conn = sqlite3.connect('ITTprojectData.db')

print "opened successfully"

#login
conn.execute("CREATE TABLE Login (UserID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT , TYPE TEXT );")

conn.execute("INSERT INTO Login (UserID, USERNAME, PASSWORD , TYPE ) VALUES (1,'student1','helloworld','student');")
conn.execute("INSERT INTO Login ( USERNAME, PASSWORD , TYPE ) VALUES ('company1','helloworld','company');")


#Internship
conn.execute("CREATE TABLE Internship ( IntID INTEGER PRIMARY KEY AUTOINCREMENT, CompanyName TEXT, CompanyDescp TEXT,Criteria TEXT, Profile TEXT ,InternshipDescp TEXT,LastDate TEXT,Stipend TEXT,Location TEXT,Duration TEXT);")

conn.execute("INSERT into Internship (IntID, CompanyName, CompanyDescp, Criteria, Profile, InternshipDescp, LastDate, Stipend, Location, Duration) VALUES (1, 'Microsoft', 'Microsoft Corporation is an American multinational technology company with headquarters in Redmond, Washington. It develops, manufactures, licenses, supports and sells computer software, consumer electronics, personal computers, and services.','CGPA: 7', 'Software Engineer', 'For those interested in working with software developers and writing code for applications and systems, becoming a computer programmer could be a good career move. Utilizing computer languages such as Java and C++, programmers construct working software products, run performance tests and find ways to eliminate bugs in the programs.','2017-11-01', '3500', 'Bangalore', '2 months');")

conn.execute("INSERT into Internship (IntID, CompanyName, CompanyDescp, Criteria, Profile, InternshipDescp, LastDate, Stipend, Location, Duration) VALUES (2,'Amazon', 'Amazon.com, Inc., doing business as Amazon, is an American electronic commerce and cloud computing company based in Seattle, Washington that was founded by Jeff Bezos on July 5, 1994.','CGPA: 6', 'Software Engineer', 'Entering the profession requires a bachelors degree computer science a related field. However, some employers may hire someone significant programming knowledge & an associate degree computer studies. Reported by the BLSv 2015, the median yearly salary of computer programmers was $79,530. The BLS also projected an 8 decrease available programming jobs 2014 2024, any potential openings occurring the mobile Internet technology industries. ', '2017-11-02','4500','Delhi', '3 months');")

#Student
conn.execute("CREATE TABLE student ( CompanyName TEXT , STUDENTNAME TEXT , EMAIL TEXT , CITY TEXT , TYPE TEXT, DISC TEXT,StdID INTEGER PRIMARY KEY AUTOINCREMENT);")

#conn.execute("INSERT INTO student (CompanyName, STUDENTNAME, EMAIL, CITY, TYPE, DISC) VALUES ('Microsoft' , 'Syed' , 'syed@gmail.com' , 'Manipal' , 'Interview' , 'Bohot Maza Aaya');")



conn.commit();
