#!C:\Python27\python.exe

import cgi,cgitb
import sqlite3
conn = sqlite3.connect('ITTprojectData.db')

print "Content-Type:text/html\r\n\r\n"

print "<html>"
print "<head><title>Internship Portal</title><link href=\"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700\" rel=\"stylesheet\">"
print "<link href=\"https://fonts.googleapis.com/css?family=Yellowtail\" rel=\"stylesheet\">"

print '''
<script type="text/javascript">
// hide header on scroll
	window.onscroll = function(){
	if(window.pageYOffset <= 260){
		var position = window.pageYOffset;
		var opacity = (100 - (position * 100 / 260)) / 100;
		document.getElementById("header").style.opacity = opacity;
	}
}

</script>
'''

print ''' 
<style> 
	* {
	margin: 0;
	padding: 0;
	border: none;
	outline: none;
	font-family: 'Roboto', sans-serif;
}
button {
	font-family: 'Roboto', sans-serif;
}
body {
	background: #f0f0f0;
	padding-top: 60px;
	min-width: 333px;
}
.wrapper {
	width: 100%;
	max-width: 999px;
	margin: 0 auto;
}
/*TOPBAR BEGIN*/
.topbar {
	z-index: 999;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	padding: 10px 0;
	background: #4488ff;
	box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}
.topbar .title {
	margin-left: 15px;
	height: 40px;
	float: left;
	display: block;
	line-height: 40px;
	color: #ffffff;
	font-size: 30px;
	font-family: 'Yellowtail', cursive;
}
.topbar nav {
	margin-right: 15px;
	float: right;
}
.topbar .close_nav ,
.topbar .nav_button {
	display: none;
}
@media screen and (max-width: 600px){
	.topbar .title {
		float: none;
		width: 100%;
		text-align:center;
	}
	.topbar nav{
		float: none;
		margin: 0;
		width: 170px;
		height: 100%;
		position: fixed;
		top: 0;
		right: -180px;
		background: #4488ff;
		box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
		transition-duration: 0.3s;
	}
	.topbar nav.active {
		right: 0;
	}
	.topbar nav a{
		float: none;
	}
	.topbar .nav_button {
		display: block;
		position: absolute;
		right:14px;
		top:  14px;
		height:32px;
		width: 32px;
		background: none;
		background-image: url(../img/nav.png);
		background-position: center;
		background-repeat: no-repeat;
		cursor: pointer;
	}
	.topbar .close_nav {
		display: block;
		height: 40px;
		color: #ffffff;
		width: 100%;
		background: none;
		font-size: 16px;
		font-weight: 500;
		background-image: url(../img/right.png);
		background-position: 130px center;
		background-size: 20px 20px;
		background-repeat: no-repeat;
		cursor: pointer;
	}
}
.topbar a{
	float: left;
	height: 40px;
	line-height: 40px;
	text-decoration: none;
	display: block;
	color: #ffffff;
	margin: 0 0 0 30px;
	font-size: 16px;
	font-weight: 500;
}
/*TOPBAR END*/
/*POSTS BEGIN*/
.posts {
	position: relative;
	padding: 30px 2px 70px 2px;
	text-align: center;
	overflow: hidden;
	max-width: 1003px;
}
@media screen and (max-width: 1006px){
	.posts {
		padding: 30px 0 70px 0;
	}
}
.post {
	text-align: left;
	background: #ffffff;
	width: 303px;
	display: inline-block;
	margin: 15px;
	border-radius:2px;
	box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
	transition: all 0.3s cubic-bezier(.25,.8,.25,1);
}
.post:hover{
	box-shadow: rgba(0, 0, 0, 0.3) 0px 10px 25px 0px;
}
.post img {
	width: 100%;
}
.post .share {
	z-index: 2;
	position: relative;
	margin: -20px 20px 0 0;
	float: right;
	height: 40px;
	width:  40px;
	background: #4488ff;
	border-radius: 20px;
	cursor: pointer;
	box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
	transition: all 0.3s cubic-bezier(.25,.8,.25,1);
	background-image: url(../img/share.png);
	background-position: center;
	background-repeat: no-repeat;
	background-size: 20px 20px;
}
.post .share:hover{
	box-shadow: 0 10px 20px rgba(0,0,0,0.5), 0 10px 10px rgba(0,0,0,0.5);
}
.post .title {
	font-size: 22px;
	display: block;
	padding: 20px 15px;
	color: #505050;
	font-weight: 400;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}
.post p {
	font-size: 15px;
	display: block;
	display: -webkit-box;
	padding: 0 15px 0 15px;
	margin-bottom: 15px;
	color: #727272;
	font-weight: 400;
	line-height: 20px;
	box-sizing: border-box;
	
    height: 40px;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
	text-overflow: ellipsis;
}
.post .more {
	font-size: 17px;
	font-weight: 400;
	padding: 8px 15px;
	color: #4488ff;
	background: #ffffff;
	float: left;
	cursor: pointer;
	margin: 0 0 15px 15px;
	border-radius: 2px;
	transition-duration: 0.3s;
}
.post .more:hover {
	background: #eeeeee;
}
.post .content {
	display: none;
}
.post .back {
	display: none;
}
/*POSTS END*/
/*ARTICLE BEGIN*/
header {
	height:400px;
	width:100%;
	background-image:url(../img/post5.jpg);
	background-size:cover;
	background-position:center;
	background-attachment:fixed;
}
article {
	padding: 30px 40px;
	box-sizing: border-box;
	background: #ffffff;
	width: 100%;
	box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
	text-align: left;
	font-size: 18px;
	line-height: 28px;
	color: #404040;
	font-weight: 300;
}
article .title {
	margin-bottom: 50px;
	font-size: 24px;
	display: block;
	color: #505050;
	font-weight: 400;
}
article p {
	display: block;
	margin: 0 0 40px 0;
}
article h2,
article li {
	font-weight: 400;
	font-size: 20px;
	line-height: 28px;
	margin: 10px 0;
	padding: 0;
}
article img{
	width: calc(100% + 80px);
	display: block;
	margin: 20px 0 20px -40px;
}
article .comments {
	background: #EEEEEE;
	width: calc(100% + 80px);
	display: block;
	margin: 20px 0 -30px -40px;
	padding: 30px;
	box-sizing: border-box;
}
article .comment {
	margin-bottom: 20px;
}
article .comment .user_info{
	overflow:hidden;
	line-height: 25px;
	font-size: 15px;
	color: #707070;
	font-weight:300;
}
article .comment .user_info img{
	float: left;
	height: 50px;
	width:  50px;
	border-radius: 30px;
	margin:0 10px 0 0 ;
}
article .comment .user_info h2{
	height: 30px;
	margin:0;
	padding: 0;
	line-height: 30px;
	display: block;
	font-size: 18px;
	color: #404040;
	font-weight: 400;
}
article .comment p{
	font-size: 16px;
	margin-top: 10px;
}
article .comment .comment{
	padding-left: 50px;
	margin: 0;
}
#right {
	width:130px;
	height:32px;
	
	border:none;
	background:#1EA6CC;
	color:#ffffff;
	cursor:pointer;
	align:center;
}
'''
print "</style>"


print "</head><body><div class=\"topbar\"><div class=\"wrapper\"><span class=\"title\">Internship Portal</span>"
print "	<button class=\"nav_button\" onclick=\"nav();\"></button><nav id=\"nav\"><button class=\"close_nav\" onclick=\"nav();\">Close</button>"
print "<a href=\"/cgi-bin/main.py\"> Intership Openings </a>"
print "<a href=\"/cgi-bin/main-3.py\"> Experiences </a><a href=\"../html/studentform.html\">Add</a></nav>"

a9 = int(1);
print "</div></div>" 

#conn.execute("CREATE TABLE Internship (0IntID INTEGER PRIMARY KEY AUTOINCREMENT,1 CompanyName TEXT,2 CompanyDescp TEXT,3 Criteria TEXT,4 Profile TEXT ,5InternshipDescp TEXT,6LastDate DATE,7Stipend Int,8Location TEXT,9Duration REAL);")
cursor=conn.execute("Select * from Internship;")
for row in cursor:

	a1=row[1]
	a2=row[4]
	a3=row[9]
	a4=row[3]
	a5=row[6]
	a6=row[6]
	a7=row[7]
	a8=row[8]

	print "<header id=\"header\" style=\"background-image:url(https://www.studyabroad.com/sites/default/files/images/iStock-498861460.jpg);\"></header><div class=\"wrapper posts\" style=\"margin-top: -100px;\">"
	print "	<article><span class=\"title\"><h1>"
	print a1
	print "</h1></span><p><h2>"
	print a2					
	print "</h2></p>"
	print "<h2>Duration:"
	print a3
	print " <br>Stipend:"
	print a7 
	print " rupees<br>"
	print a4					
	print " required</h2><p><h3>Apply by date: %s</h3>" %a5
	print "</h3>"
	print "<br>Location: "
	print a8				
	print "</p>"
	print "<form action = \"/cgi-bin/main-2.py\" method = \"POST\"> <input type = \"hidden\" name = \"ID\" value = %s> <input type = \"submit\" name=\"abc\" value=\"APPLY\" align=\"right\" id=\"right\">" %(a9)
	a9 = a9+1
	print "</article>"
	print "<section></section></div>"

print "</body></html>"
